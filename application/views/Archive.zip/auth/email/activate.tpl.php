<html>
<body>
	<strong>Kính gửi Quý công ty!</strong>
	<p>Công ty đã sử dụng mail: <?php echo $identity ?> để đăng ký tài khoản tham gia chương trình Danh hiệu Sao Khuê 2019.</p>
	<p><?php echo sprintf(lang('email_activate_subheading'), anchor('client/user/activate/'. $id .'/'. $activation, 'đây'));?> để kích hoạt tài khoản và khai hồ sơ.</p>
	<p>Trường hợp không đăng nhập được vui lòng liên hệ: <strong>Anh Mạc Công Minh</strong>, mobile: 0936 136 696, email: minhmc@vinasa.org.vn để được hỗ trợ</p>
	<br>
	<br>
	<br>
	<p>Trân trọng!</p>
</body>
</html>